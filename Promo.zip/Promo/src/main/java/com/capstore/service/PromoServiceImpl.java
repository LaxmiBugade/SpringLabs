package com.capstore.service;

import java.util.List;

import com.capstore.bean.Promo;

public class PromoServiceImpl implements PromoService{

	@Override
	public void savePromo(Promo promo) {
		
	}

	@Override
	public Promo get(int promo_id) {
		return null;
	}

	@Override
	public List<Promo> getAll() {
		return null;
	}

}
