package com.capstore.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PromoController {
	
	@GetMapping("/hi")
	public String sayHi() {
		return "Hi from CapStore";
	}
	
	//Add new Promo to DB
	
	
//	@PostMapping("/add")
//	public String saveProduct(@RequestParam("name") String name,
//			@RequestParam("price") double price) {
//		
//		Product p = new Product(); 
//		p.setName(name);
//		p.setPrice(price);
//		proService.save(p);
//		return "Pro saved";
//	}

}
