package com.capstore.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Promo {

	@Id
	@GeneratedValue
	private int promo_id;
	
	private String promo_title;
	private String promo_description;
	private String image_path;
	private String product_name;
	private String category;
	private int discount_amount;
	private Date expiry_date;
	
	
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getDiscount_amount() {
		return discount_amount;
	}
	public void setDiscount_amount(int discount_amount) {
		this.discount_amount = discount_amount;
	}
	public Date getExpiry_date() {
		return expiry_date;
	}
	public void setExpiry_date(Date expiry_date) {
		this.expiry_date = expiry_date;
	}
	public int getPromo_id() {
		return promo_id;
	}
	public void setPromo_id(int promo_id) {
		this.promo_id = promo_id;
	}
	public String getPromo_title() {
		return promo_title;
	}
	public void setPromo_title(String promo_title) {
		this.promo_title = promo_title;
	}
	public String getPromo_description() {
		return promo_description;
	}
	public void setPromo_description(String promo_description) {
		this.promo_description = promo_description;
	}
	public String getImage_path() {
		return image_path;
	}
	public void setImage_path(String image_path) {
		this.image_path = image_path;
	}
	
	
}
