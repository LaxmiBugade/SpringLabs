package com.cg.service;

import com.cg.entity.Product;

public interface ProductService {
	public String addProduct(Product p);
}
