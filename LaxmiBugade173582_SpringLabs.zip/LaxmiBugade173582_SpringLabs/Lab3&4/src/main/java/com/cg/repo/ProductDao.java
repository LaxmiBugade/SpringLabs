package com.cg.repo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;

@RestController
public class ProductDao {

	private static final Map<Integer, Product> proMap = new HashMap<Integer, Product>();

	ProductDao() {
		Product p1 = new Product(101, "Laptop", 45678.34);
		Product p2 = new Product(102, "Ipad", 65678.84);
		Product p3 = new Product(103, "Iphone", 84678.34);
		Product p4 = new Product(104, "Ipod", 1200.34);

		proMap.put(101, p1);
		proMap.put(102, p2);
		proMap.put(103, p3);
		proMap.put(104, p4);

	}

	public static Product addProduct(Product p) {
		proMap.put(p.getProdId(), p);
		return p;
	}

	public static List<Product> getAllProduct() {
		Collection<Product> c = proMap.values();
		List<Product> list = new ArrayList<Product>();
		list.addAll(c);
		return list;
	}
}
