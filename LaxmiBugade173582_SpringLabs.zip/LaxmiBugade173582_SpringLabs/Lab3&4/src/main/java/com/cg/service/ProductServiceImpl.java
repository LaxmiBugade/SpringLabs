package com.cg.service;

import java.util.List;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Product;
import com.cg.repo.ProductDao;

@Path("/product")
public class ProductServiceImpl{
	 
    @RequestMapping(value="/get")
    @Produces(MediaType.APPLICATION_JSON)
    public String getAllProduct(Model model) {
        List<Product> listOfProduct = ProductDao.getAllProduct();
        model.addAttribute("product", listOfProduct);
        return "get";
    }
 
    @RequestMapping(value="/addProduct", method = RequestMethod.GET)
    public String showAddPage(Model model) {
    	model.addAttribute("product");
 		return "addProduct";
 	}
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public ModelAndView addProduct(@ModelAttribute("product") Product product) {
    	ModelAndView model = new ModelAndView("product");
        ProductDao.addProduct(product);
        ((Model) model).addAttribute("product", product);
        return new ModelAndView("redirect:/get");
    }

    @ExceptionHandler({
		org.springframework.web.util.NestedServletException.class
	})
	public ModelAndView showError() {
		return new ModelAndView("Errors occured");
	}
}
