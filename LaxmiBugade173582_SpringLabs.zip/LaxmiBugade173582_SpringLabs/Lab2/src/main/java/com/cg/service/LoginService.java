package com.cg.service;

import org.springframework.stereotype.Service;

@Service("service")
public class LoginService {

	public boolean validateUser(String name, String password) {
		 return name.equals("laxmi")
	                && password.equals("laxmi");
	}

}
