package com.cg.statement4;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeExecutor {

	public static void main(String[] args) {
		
		System.out.println("Enter employee id to display details");
		Scanner sc = new Scanner(System.in);
		
		int id = sc.nextInt();
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("emp.xml");
		EmployeeCollection e = (EmployeeCollection) ctx.getBean("e7");
		e.check(id);
		//System.out.println(e);
	}
}
