package com.cg.statement4;

import java.util.Map;

public class EmployeeCollection {

	//Map declared
	private Map<Integer,Employee> empMap;

	//Getters & setters
	public Map<Integer, Employee> getEmpMap() {
		return empMap;
	}

	public void setEmpMap(Map<Integer, Employee> empMap) {
		this.empMap = empMap;
	}
	
	//Method to check id is exist or not
	public void check(int id) {
		if(empMap.containsKey(id)) {
			System.out.println(empMap.get(id));
		}else {
			System.out.println("Employee Id is not exist");
		}
	}
}
