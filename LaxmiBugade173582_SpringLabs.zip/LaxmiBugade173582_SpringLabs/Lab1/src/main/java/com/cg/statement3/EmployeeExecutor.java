package com.cg.statement3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeExecutor {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("emp.xml");
		SBU s = (SBU) ctx.getBean("sbu1");
		System.out.println(s);
	}
}
