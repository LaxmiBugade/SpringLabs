package com.cg.statement1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeExecutor {

	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("emp.xml");
		Employee emp = (Employee) ctx.getBean("e1");
		System.out.println(emp);
	}
}
